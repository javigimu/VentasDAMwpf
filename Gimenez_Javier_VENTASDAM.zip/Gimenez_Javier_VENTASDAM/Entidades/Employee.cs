﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.Metrics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Xml.Linq;
using Microsoft.EntityFrameworkCore;

namespace Modelos
{
    /// <summary>
    /// Clase Employee.
    /// Version 1.0
    /// <autor>Javier Giménez</autor> 
    /// </summary>
    [Index("LastName", Name = "LastName")]
    [Index("PostalCode", Name = "PostalCode")]    
    public partial class Employee : IComparable<Employee>, INotifyPropertyChanged
    {
        private int _employeeId;
        private string _firstName;
        private string _lastName;
        private string? _title;
        private string? _titleOfCourtesy;
        private DateTime? _birthDate;
        private DateTime? _hireDate;
        private string? _address;
        private string? _city;
        private string? _region;
        private string? _postalCode;
        private string? _country;
        private string? _homePhone;
        private string? _extension;
        private byte[]? _photo;
        private string? _notes;
        private string? _photoPath;
        private int? _reportsTo;

        /// <summary>
        /// Clave primaria del empleado.
        /// </summary>
        [Key]
        [Column("EmployeeID")]
        public int EmployeeId
        {
            get { return _employeeId; }
            set
            {
                _employeeId = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Apellido del empleado con longitud máxima de 20 caracteres
        /// </summary>
        [StringLength(20)]
        public string LastName
        {
            get { return _lastName; }
            set
            {
                _lastName = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Nombre del empleado con longitud máxima de 10 caracteres
        /// </summary>
        [StringLength(10)]
        public string FirstName 
        { 
            get { return _firstName; } 
            set
            {
                _firstName = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Cargo del empleado con longitud máxima de 30 caracteres
        /// </summary>
        [StringLength(30)]
        public string? Title 
        { 
            get { return _title; }
            set
            {
                _title = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Título de cortesía con longitud máxima de 25 caracteres
        /// </summary>
        [StringLength(25)]
        public string? TitleOfCourtesy 
        { 
            get { return _titleOfCourtesy; } 
            set 
            { 
                _titleOfCourtesy= value; 
                OnPropertyChanged(); 
            }
        }
        /// <summary>
        /// Fecha de nacimiento del empleado
        /// </summary>
        [Column(TypeName = "datetime")]
        public DateTime? BirthDate 
        {
            get { return _birthDate; }
            set
            {
                _birthDate = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Fecha de contratación del empleado
        /// </summary>
        [Column(TypeName = "datetime")]
        public DateTime? HireDate 
        { 
            get { return _hireDate; } 
            set
            {
                _hireDate = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Dirección de residencia del empleado con longitud máxima de 60 caracteres
        /// </summary>
        [StringLength(60)]
        public string? Address 
        { 
            get { return _address; }
            set
            {
                _address = value;
                OnPropertyChanged();    
            }
        }
        /// <summary>
        /// Ciudad de residencia del empleado con longitud máxima de 15 caracteres
        /// </summary>
        [StringLength(15)]
        public string? City 
        { 
            get { return _city; }
            set
            {
                _city = value;
                OnPropertyChanged();
            } 
        }
        /// <summary>
        /// Provincia de residencia del empleado con longitud máxima de 15 caracteres
        /// </summary>
        [StringLength(15)]
        public string? Region 
        { 
            get { return _region; } 
            set
            {
                _region = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Código postal de residencia del empleado con longitud máxima de 10 caracteres
        /// </summary>
        [StringLength(10)]
        public string? PostalCode 
        { 
            get { return _postalCode; } 
            set
            {
                _postalCode = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// País de residencia del empleado con longitud máxima de 15 caracteres
        /// </summary>
        [StringLength(15)]
        public string? Country 
        { 
            get { return _country; }
            set
            {
                _country = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Teléfono personal del empleado con longitud máxima de 24 caracteres
        /// </summary>
        [StringLength(24)]
        public string? HomePhone 
        { 
            get { return _homePhone; } 
            set
            {
                _homePhone = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Extensión para el teléfono del empleado con longitud máxima de 4 caracteres
        /// </summary>
        [StringLength(4)]
        public string? Extension 
        { 
            get { return _extension; }
            set
            {
                _extension = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Foto personal para identificar al empleado
        /// </summary>
        [Column(TypeName = "image")]
        public byte[]? Photo 
        { 
            get { return _photo; } 
            set
            {
                _photo = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Información adicional del empleado
        /// </summary>
        public string? Notes 
        { 
            get { return _notes; }
            set
            {
                _notes = value;
                OnPropertyChanged();
            } 
        }
        /// <summary>
        /// Identificador del empleado supervisor
        /// </summary>
        public int? ReportsTo 
        { 
            get { return _reportsTo; } 
            set
            {
                _reportsTo = value;
                OnPropertyChanged();
            }
        }
        /// <summary>
        /// Ruta de acceso a la foto del empleado con longitud máxima de 255 caracteres
        /// </summary>
        [StringLength(255)]
        public string? PhotoPath 
        { 
            get { return _photoPath; } 
            set
            {
                _photoPath = value;
                OnPropertyChanged();
            }
        }

        /// <summary>
        /// Clave ajena a Employees para enlazar los reportes al supervisor
        /// </summary>
        [ForeignKey("ReportsTo")]
        [InverseProperty("InverseReportsToNavigation")]
        public virtual Employee? ReportsToNavigation { get; set; }
        /// <summary>
        /// Propiedad inversa para gestionar los reportes al supervisor
        /// </summary>
        [InverseProperty("ReportsToNavigation")]        
        public virtual ICollection<Employee>? InverseReportsToNavigation { get; set; }
        /// <summary>
        /// Colección con los pedidos realizados por el empleado
        /// </summary>
        [InverseProperty("Employee")]
        public virtual ICollection<Order>? Orders { get; set; }

        /// <summary>
        /// Constructor por defecto
        /// </summary>
        public Employee()
        {
            InverseReportsToNavigation = new HashSet<Employee>();
            Orders = new HashSet<Order>();
        }

        /// <summary>
        /// Constructor con todos los parámetros
        /// </summary>
        /// <param name="employeeId">Id de empleado</param>
        /// <param name="lastName">Apellido del empleado</param>
        /// <param name="firstName">Nombre del empleado</param>
        /// <param name="title">Cargo del empleado</param>
        /// <param name="titleOfCourtesy">Título de cortesía (Mr., Ms., Dr. Mrs.)</param>
        /// <param name="birthDate">Año de nacimiento del empleado</param>
        /// <param name="hireDate">Año de contratación del empleado</param>
        /// <param name="address">Dirección del empleado</param>
        /// <param name="city">Ciudad de residencia del empleado</param>
        /// <param name="region">Provincia de residencia del empleado</param>
        /// <param name="postalCode">Código postal de residencia del empleado</param>
        /// <param name="country">País de residencia del empleado</param>
        /// <param name="homePhone">Télefono personal del empleado</param>
        /// <param name="extension">Extensión del teléfono del empleado</param>
        /// <param name="photo">Foto identificación del empleado</param>
        /// <param name="notes">Información adicional del empleado</param>
        /// <param name="photoPath">Ruta de acceso a la foto del empleado</param>
        /// <param name="reportsTo">Empleado supervisor del empleado</param>
        public Employee(int employeeId, string lastName, string firstName, 
            string? title, string? titleOfCourtesy, DateTime? birthDate, 
            DateTime? hireDate, string? address, string? city, string? region, 
            string? postalCode, string? country, string? homePhone, 
            string? extension, byte[]? photo, string? notes, string? photoPath,
            int reportsTo)
            :this()
        {
            _employeeId = employeeId;
            _lastName = lastName;
            _firstName = firstName;
            _title = title;
            _titleOfCourtesy = titleOfCourtesy;
            _birthDate = birthDate;
            _hireDate = hireDate;
            _address = address;
            _city = city;
            _region = region;
            _postalCode = postalCode;
            _country = country;
            _homePhone = homePhone;
            _extension = extension;
            _photo = photo;
            _notes = notes;
            _photoPath = photoPath;
            _reportsTo = reportsTo;
        }

        /// <summary>
        /// Constructor con los parámetros obligatorios
        /// </summary>
        /// <param name="employeeId">Código de identificación del empleado</param>
        /// <param name="lastName">Apellido del empleado</param>
        /// <param name="firstName">Nombre del empleado</param>
        public Employee(int employeeId, string lastName, string firstName)
            :this(employeeId, lastName, firstName, null, null, null, null, null, null, null,
                 null, null, null, null, null, null, null, -1)
        { }

        /// <summary>
        /// Constructor de copia
        /// </summary>
        /// <param name="e">Empleado del que se realiza la copia</param>
        public Employee(Employee e)
        {
            _employeeId = e.EmployeeId;
            _lastName = e.LastName;
            _firstName = e.FirstName;
            _title = e.Title;
            _titleOfCourtesy = e.TitleOfCourtesy;
            _birthDate = e.BirthDate;
            _hireDate = e.HireDate;
            _address = e.Address;
            _city = e.City;
            _region = e.Region;
            _postalCode = e.PostalCode;
            _country = e.Country;
            _homePhone = e.HomePhone;
            _extension = e.Extension;

            if (e.Photo != null)
            {
                _photo = new byte[e.Photo.Length];
                for (int i = 0; i < e.Photo.Length; i++)
                    _photo[i] = e.Photo[i];
            }
            else
                _photo = null;

            if (e.InverseReportsToNavigation != null)
            {
                foreach (Employee emp in e.InverseReportsToNavigation)
                    InverseReportsToNavigation?.Add(emp);

            }

            if (e.Orders != null)
            {
                foreach (Order o in e.Orders)
                    Orders?.Add(o);
            }

            Notes = e.Notes;           
        }

        /// <summary>
        /// Método de comparación.
        /// La interfaz IComparable exige la implementación de un método CompareTo.
        /// Se realiza la ordenación por Firstname y después por Lastname
        /// </summary>
        /// <param name="otro">Segundo empleado para realizar la comparación</param>
        /// <returns>-1 si el empleado actual es menor que el recibido por parámetro, 
        /// 0 si los dos empleados son iguales o 1 si el empleado actual es mayor que el recibido por parámetro</returns>
        public int CompareTo(Employee? otro)
        {            
            int resultado = 0;

            if (FirstName.CompareTo(otro?.FirstName) < 0)
                resultado = -1;
            else if (FirstName.CompareTo(otro?.FirstName) > 0)
                resultado = 1;
            else
            {
                if (LastName.CompareTo(otro?.LastName) < 0)
                    resultado = -1;
                else if (LastName.CompareTo(otro?.LastName) > 0)
                    resultado = 1;
            }
            return resultado;
        }

        /// <summary>
        /// Sobrecarga del método ToString.
        /// </summary>
        /// <returns>Una cadena de texto con todos los datos del empleado separados por #</returns>
        public override string ToString()
        {
            return EmployeeId + "#" + LastName + "#" + FirstName
                + "#" + Title + "#" + TitleOfCourtesy + "#" + BirthDate
                + "#" + HireDate + "#" + Address + "#" + City + "#" + Region
                + "#" + PostalCode + "#" + Country + "#" + HomePhone
                + "#" + Extension + "#" + Photo + "#" + Notes;
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~Employee()
        {
            if (Photo != null)
                Array.Clear(Photo);
            if (InverseReportsToNavigation != null)
                InverseReportsToNavigation.Clear();
            InverseReportsToNavigation = null;
            if (Orders != null)
                Orders.Clear();
            Orders = null;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        // Create the OnPropertyChanged method to raise the event
        // The calling member's name will be used as the parameter.
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
