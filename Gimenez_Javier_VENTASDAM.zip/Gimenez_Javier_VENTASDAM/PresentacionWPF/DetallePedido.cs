﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace PresentacionWPF
{
    /// <summary>
    /// <autor>Javier Giménez</autor>
    /// Clase auxiliar para mostrar todos los datos en el informe, incluido el total autocalculado de cada producto
    /// </summary>
    public class DetallePedido
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public int Discount { get; set; }
        public decimal Total
        {
            get { return UnitPrice * Quantity * (decimal)(1 - (Discount/100.0f)); }
        }

        public DetallePedido(int ProductId, string ProductName, decimal UnitPrice, int Quantity, int Discount)
        {
            this.ProductId = ProductId;
            this.ProductName = ProductName;
            this.UnitPrice = UnitPrice;
            this.Quantity = Quantity;
            this.Discount = Discount;
        }
    }
}
