﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.Dialogos
{
    /// <summary>
    /// Lógica de interacción para PeticionIntervaloTemporizador.xaml
    /// </summary>
    public partial class PeticionIntervaloTemporizador : Window
    {
        private int tiempoIntervalo;

        public PeticionIntervaloTemporizador()
        {
            InitializeComponent();
        }

        private void btnDialogOk_Click(object sender, RoutedEventArgs e)
        {
            tiempoIntervalo = Convert.ToInt32(tbIntevalo.Text.Trim());
            this.DialogResult = true;
        }

        public int getTiempoIntervalo()
        {
            return tiempoIntervalo;
        }

        /// <summary>
        /// Sólo permite introducir números en un textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
