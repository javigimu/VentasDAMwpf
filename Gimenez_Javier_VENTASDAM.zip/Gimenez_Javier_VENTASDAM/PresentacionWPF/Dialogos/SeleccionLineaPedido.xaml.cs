﻿using Modelos;
using Negocio;
using PresentacionWPF.UserControls;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF
{
    /// <summary>
    /// <autor>Javier Giménez</autor>
    /// Lógica de interacción para SeleccionLineaPedido.xaml
    /// </summary>
    public partial class SeleccionLineaPedido : Window
    {
        private Product? producto;
        private ObservableCollection<Product>? listaObservableProductos;
        private CollectionViewSource miVista;
        private string? textoFiltrado;

        public SeleccionLineaPedido()
        {
            InitializeComponent();
            producto = new Product();
            miVista = (CollectionViewSource)FindResource("listaProductos");
            listaObservableProductos = new ObservableCollection<Product>(Gestion.ListadoProductos());
            textoFiltrado = "";
        }

        /// <summary>
        /// Inicialmente se muestran los datos obtenidos de la tabla empleados en la base de datos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            miVista.Source = listaObservableProductos;
            producto = (Product)lvProductos.SelectedItem;
        }

        
        private void btnDialogOk_Click(object sender, RoutedEventArgs e)
        {
            producto = (Product)lvProductos.SelectedItem;
            this.DialogResult = true;
        }

        /// <summary>
        /// Reacciona cada vez que se introduce un carácter en el texbox de filtrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            miVista.Filter += FiltrarPorNombreProducto;
        }

        /// <summary>
        /// Filtra los productos tras introducir texto en el campo tbTextoFiltrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void manejarDoubleClick(object sender, MouseButtonEventArgs e)
        {
            producto = (Product)lvProductos.SelectedItem;
            this.DialogResult = true;
        }

        /// <summary>
        /// Filtra los empleados cuyo nombre, apellido o ciudad contengan el texto introducido por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FiltrarPorNombreProducto(object sender, FilterEventArgs e)
        {
            Product prodFiltrado = (Product)e.Item;
            if (prodFiltrado != null)
            {
                string nombre = prodFiltrado.ProductName == null ? "" : prodFiltrado.ProductName;

                if (nombre.ToLower().Contains(textoFiltrado!.ToLower()))
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Devuelve el producto seleccionado
        /// </summary>
        /// <returns></returns>
        public Product? getProduct()
        {
            return producto;
        }

        /// <summary>
        /// Devuelve la cantidad seleccionada que por defecto es 1
        /// </summary>
        /// <returns></returns>
        public short getCantidad()
        {
            if (tbCantidad.Text.Trim().Length == 0 || tbCantidad.Text.Trim().Length > 16)
                return 1;
            else
                return Convert.ToInt16(tbCantidad.Text.Trim());
        }

        /// <summary>
        /// Devuelve el descuento seleccionado que por defecto es 0
        /// </summary>
        /// <returns></returns>
        public int getDescuento()
        {
            if (tbCantidad.Text.Trim().Length == 0)
                return 0;
            else
                return Convert.ToInt32(tbDescuento.Text.Trim());
        }

        /// <summary>
        /// Sólo permite introducir números en un textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void tbCantidad_LostFocus(object sender, RoutedEventArgs e)
        {
            if (tbCantidad.Text.Trim().Length == 0)
                tbCantidad.Text = "1";
        }

        private void tbDescuento_LostFocus(object sender, RoutedEventArgs e)
        {
            if (tbDescuento.Text.Trim().Length == 0)
                tbDescuento.Text = "0";
        }
    }
}
