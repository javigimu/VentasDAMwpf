﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF.Dialogos
{
    /// <summary>
    /// Lógica de interacción para SeleccionPedido.xaml
    /// <autor>Javier Giménez</autor>
    /// </summary>
    public partial class SeleccionPedido : Window
    {
        private Order? pedido;
        private ObservableCollection<Order>? listaObservablePedidos;
        private CollectionViewSource miVista;
        private string? textoFiltrado;

        public SeleccionPedido()
        {
            InitializeComponent();
            pedido = new Order();
            miVista = (CollectionViewSource)FindResource("listaPedidos");
            listaObservablePedidos = new ObservableCollection<Order>(Gestion.ListarPedidos());
            textoFiltrado = "";
        }

        /// <summary>
        /// Inicialmente se muestran los datos obtenidos de la tabla pedidos en la base de datos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (listaObservablePedidos != null)
            {
                miVista.Source = listaObservablePedidos.OrderByDescending(order => order.OrderId);
                pedido = (Order)lvPedidos.SelectedItem;
            }            
        }

        private void ObtenerPedido()
        {
            pedido = (Order)lvPedidos.SelectedItem;

            using (Gestion gestion = new Gestion())
            {
                if (pedido.CustomerId != null)
                    pedido.Customer = gestion.ObtenerCustomer(pedido.CustomerId);
            }
        }

        private void btnDialogOk_Click(object sender, RoutedEventArgs e)
        {
            ObtenerPedido();
            this.DialogResult = true;
        }

        /// <summary>
        /// Reacciona cada vez que se introduce un carácter en el texbox de filtrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            miVista.Filter += FiltrarPorNombreClienteYEnvio;
        }

        /// <summary>
        /// Filtra los pedidos tras introducir texto en el campo tbTextoFiltrado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void manejarDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ObtenerPedido();
            this.DialogResult = true;
        }

        /// <summary>
        /// Filtra los pedidos cuyo id de cliente, nombre de envío o id contengan el texto introducido por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FiltrarPorNombreClienteYEnvio(object sender, FilterEventArgs e)
        {
            Order pedidoFiltrado = (Order)e.Item;
            if (pedidoFiltrado != null)
            {
                string nombre = pedidoFiltrado.CustomerId == null ? "" : pedidoFiltrado.CustomerId;
                string nombreEnvio = pedidoFiltrado.ShipName == null ? "" : pedidoFiltrado.ShipName;

                if (nombre.ToLower().Contains(textoFiltrado!.ToLower()) ||
                    nombreEnvio.ToLower().Contains(textoFiltrado!.ToLower()) ||
                    pedidoFiltrado.OrderId.ToString().Contains(textoFiltrado!))
                {
                    e.Accepted = true;
                }
                else
                {
                    e.Accepted = false;
                }
            }
        }

        /// <summary>
        /// Devuelve el producto seleccionado
        /// </summary>
        /// <returns></returns>
        public Order? getPedido()
        {
            return pedido;
        }
    }
}
