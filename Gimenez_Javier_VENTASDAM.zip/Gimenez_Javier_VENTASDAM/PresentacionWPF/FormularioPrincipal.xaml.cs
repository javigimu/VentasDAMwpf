﻿using DatosEEF;
using Microsoft.Win32;
using Modelos;
using PresentacionWPF.Dialogos;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Printing;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PresentacionWPF
{
    /// <summary>
    /// Lógica de interacción para FormularioPrincipal.xaml
    /// <autor>Javier Giménez Muñoz</autor>
    /// </summary>
    public partial class FormularioPrincipal : Window
    {
        private Employee? empleado;
        private bool menuLateralExtendido;
        private int tiempoIntervaloActualizacion;
        private UserControls.DashBoard? dashBoard;

        public FormularioPrincipal()
        {
            InitializeComponent();
            menuLateralExtendido = false;
            tiempoIntervaloActualizacion = 30; // intervalo de actualización del dashboard por defecto
        }

        public FormularioPrincipal(Employee empleado) : this()
        {
            this.empleado = empleado;
            MostrarDatosEmpleado();            
        }

        private void MostrarDatosEmpleado()
        {
            MostrarInformacionPersonal();
            MostrarDashBoard();
        }       

        /// <summary>
        /// Muestra la información personal del empleado en la barra superior
        /// </summary>
        private void MostrarInformacionPersonal()
        {            
            tbNombreEmpleado.Text = "Hola, " + empleado?.FirstName + " " + empleado?.LastName;
        }

        /// <summary>
        /// Al cargarse la ventana, relleno los datos con binding
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            fotoEmpleado.DataContext = empleado;
        }

        /// <summary>
        /// Cierra el formulario y sale de la aplicación
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Salir(object sender, RoutedEventArgs e)
        {
            ConfirmacionSalida dialogoConfirmacion = new ConfirmacionSalida("Se va a cerrar la aplicación, ¿Continuar?");
            if (dialogoConfirmacion.ShowDialog() == true)
                Close();
        }

        /// <summary>
        /// Muestra la información del DashBoard actualizable con el temporizador
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void MostrarDashBoard()
        {
            stackPanelPrincipal.Children.Clear();            
            if (empleado != null)
            {
                dashBoard = new UserControls.DashBoard(empleado, tiempoIntervaloActualizacion);
                stackPanelPrincipal.Children.Add(dashBoard);
            }
        }
                

        /// <summary>
        /// Muestra el formulario para insertar nuevos empleados
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarFormInsertarEmpleados(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            if (empleado != null)
                stackPanelPrincipal.Children.Add(new UserControls.Empleados());
        }

        /// <summary>
        /// Muestra el formulario principal del DashBoard
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MostrarDashBoard(object sender, RoutedEventArgs e)
        {
            MostrarDashBoard();
        }      

        private void MostrarFormModificarEmpleados(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.BuscarEmpleado("modificar"));
        }

        private void MostrarFormBorrarEmpleados(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.BuscarEmpleado("eliminar"));
        }

        private void MostrarFormProductos(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.Productos());
        }

        private void MostrarPedidos(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            if (empleado != null)
                stackPanelPrincipal.Children.Add(new UserControls.Pedidos(empleado));
        }

        private void MostrarInforme(object sender, RoutedEventArgs e)
        {
            stackPanelPrincipal.Children.Clear();
            stackPanelPrincipal.Children.Add(new UserControls.Informes());
        }

        /// <summary>
        /// Método para ampliar manualmente el menú lateral
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AmpliarMenuLateral(object sender, RoutedEventArgs e)
        {
            if (!menuLateralExtendido)
            {
                menuPrincipal.Width = 200;
                menuLateralExtendido = true;
            }
            else
            {
                menuPrincipal.Width = 100;
                menuLateralExtendido = false;
            }            
        }

        /// <summary>
        /// Abre un diálogo para establecer el tiempo de actualización del dashboard
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EstablecerTemporizador(object sender, RoutedEventArgs e)
        {
            PeticionIntervaloTemporizador peticionIntevalo = new PeticionIntervaloTemporizador();
            peticionIntevalo.ShowDialog();

            if (peticionIntevalo.DialogResult == true)
            {
                tiempoIntervaloActualizacion = peticionIntevalo.getTiempoIntervalo();

                dashBoard?.ActualizarIntervaloTemporizador(tiempoIntervaloActualizacion);
            }
        }
    }
}
