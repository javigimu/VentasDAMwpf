﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Collections.Specialized.BitVector32;

namespace PresentacionWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// <author>Javier Giménez Muñoz</author>
    /// </summary>
    public partial class MainWindow : Window
    {
        private int numeroIntentos;

        /// <summary>
        /// Constructor por defecto que muestra los empleados en el listView
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            numeroIntentos = 3;
            MostrarEmpleados();
        }

        /// <summary>
        /// Muestra el nombre y la foto de los empleados
        /// </summary>
        private void MostrarEmpleados()
        {
            ICollection<Employee>? empleados = Gestion.ListadoEmpleados();
            this.DataContext = empleados;
        }

        /// <summary>
        /// Valida si el password del empleado seleccionado es correcto.
        /// Si es correcto abre la aplicación principal.
        /// Si es incorrecto, tras 3 intentos, se cierra la aplicación.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonValidarEmpleado_Click(object sender, RoutedEventArgs e)
        {
            Employee empleado;
            if (lstEmpleados.SelectedItem != null)
            {
                empleado = (Employee)lstEmpleados.SelectedItem;
                string password = passBox.Password.Trim();
                if (Utils.ValidarTextoEsNumero(password) && 
                    Convert.ToInt32(password) == empleado.EmployeeId)
                {
                    Application.Current.MainWindow = new FormularioPrincipal(empleado);
                    Application.Current.MainWindow.Show();
                    this.Close();
                }
                else
                {
                    numeroIntentos--;
                    if (numeroIntentos > 0)
                    {
                        lbError.Content = "Id incorrecto, quedan " + numeroIntentos + " intentos";
                    }
                    else
                    {
                        MessageBox.Show("Intentos de validación agotados. Se cerrará la aplicación");
                        Close();
                    }    
                }      
            } 
            else
            {
                lbError.Content = "Debes seleccionar un empleado";
            }
        }

        /// <summary>
        /// Impide que el usuario introduzca un dato no numérico
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PasswordBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Utils.ValidarTextoEsNumero(e.Text))
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// Cierra la aplicación
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonSalir_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
        
    } 
}
