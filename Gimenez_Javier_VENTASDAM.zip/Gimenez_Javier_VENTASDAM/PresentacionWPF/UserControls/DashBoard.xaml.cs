﻿using Microsoft.VisualBasic;
using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;
using LiveCharts.Wpf.Charts.Base;
using System.Security.Cryptography.X509Certificates;
using LiveCharts.Helpers;
using System.Windows.Threading;

namespace PresentacionWPF.UserControls
{
    /// <summary>
    /// Lógica de interacción para DashBoard.xaml
    /// </summary>
    public partial class DashBoard : UserControl
    {
        private Employee? empleado;
        ICollection<Order>? pedidosEmpleado;
        private int tiempoTemporizador;
        private DispatcherTimer? dtTemporizador;

        public DashBoard()
        {
            InitializeComponent();
            CrearGraficoPedidosCliente();
            CrearGraficoProductosCategoria();
        }

        /// <summary>
        /// Constructor que recibe el empleado que se ha validado en la aplicación
        /// </summary>
        /// <param name="empleado"></param>
        public DashBoard(Employee empleado, int tiempoTemporizador) : this()
        {
            this.empleado = empleado;
            if (empleado != null)
                pedidosEmpleado = Gestion.ListarPedidosEmpleado(empleado.EmployeeId);

            this.tiempoTemporizador = tiempoTemporizador;

            ActualizarInformacion();
        }

        /// <summary>
        /// Genera la gráfica circular la cantidad de productos por categoría
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void CrearGraficoProductosCategoria()
        {
            ICollection<Category>? categorias = Gestion.ListadoCategorias();
            ICollection<Product>? productos = Gestion.ListadoProductos();

            Dictionary<string, double> productosPorCategoria = new Dictionary<string, double>();
            if (productos != null && categorias != null)
            {
                foreach (Product p in productos)
                {
                    foreach (Category c in categorias)
                    {
                        if (p.CategoryId == c.CategoryId)
                        {
                            if (productosPorCategoria.ContainsKey(c.CategoryName))
                                productosPorCategoria[c.CategoryName]++;
                            else
                                productosPorCategoria.Add(c.CategoryName, 1);
                        }
                    }
                }
            }

            SeriesCollection serie = new SeriesCollection();

            foreach (KeyValuePair<string, double> dato in productosPorCategoria)
            {
                serie.Add(new PieSeries
                {
                    Title = dato.Key,
                    Values = new ChartValues<double> { dato.Value }                    
                });
            }

            graficoProductosCategoria.Series = serie;
        }

        /// <summary>
        /// Genera la gráfica de barras horizontales mostrando los pedidos por cliente
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void CrearGraficoPedidosCliente()
        {
            ICollection<Order>? pedidos = Gestion.ListarPedidos();
            Dictionary<string, double> pedidosPorCliente = new Dictionary<string, double>();
            if (pedidos != null)
            {
                foreach (Order o in pedidos)
                {
                    if (o.CustomerId != null)
                    {
                        if (pedidosPorCliente.ContainsKey(o.CustomerId))
                            pedidosPorCliente[o.CustomerId]++;
                        else
                            pedidosPorCliente.Add(o.CustomerId, 1);
                    }
                }
            }


            SeriesCollection serie = new SeriesCollection();       
            serie.Add(new RowSeries
            {
                Title = "Pedidos-Cliente",
                Values = new ChartValues<double> (pedidosPorCliente.Values)
            });

            gBarras_eje_y.Labels = new List<string>();
            foreach (KeyValuePair<string, double> dato in pedidosPorCliente)
            {
                gBarras_eje_y.Labels.Add(dato.Key);
            }

            graficoPedidosCliente.Series = serie;  
        }

        /// <summary>
        /// Actualiza la información del DashBoard
        /// </summary>
        private void ActualizarInformacion()
        {
            if (empleado != null)
            {
                DateTime fechaActual = DateAndTime.Now;

                // Pedidos del último mes (30 días)
                //lbTotalPedidos.Content = pedidosEmpleado?.Count;
                lbTotalPedidos.Content = Gestion.CalcularNumeroPedidosUltimoMes(empleado.EmployeeId);
                lbFechaPedidos.Content = "Actualizado " + fechaActual;

                // Productos
                lbTotalProductos.Content = Gestion.TotalProductosConStockMenor10();
                lbFechaProductos.Content = "Actualizado " + fechaActual;

                // Importe de los pedidos del día actual
                ICollection<Order> listaPedidosHoy = Gestion.ObtenerPedidosHoy();
                lbPedidosHoy.Content = Gestion.CalcularImportePedidosHoy(listaPedidosHoy) + " €";
                lbFechaPedidosHoy.Content = "Actualizado " + fechaActual;

                // Importe de los pedidos del día actual realizados por el empleado actual
                ICollection<Order> pedidosEmpleado = Gestion.ListarPedidosEmpleadoHoy(empleado.EmployeeId);
                lbPedidosEmpleado.Content = Gestion.CalcularImportePedidosHoy(pedidosEmpleado) + " €";
                lbFechaPedidosEmpleado.Content = "Actualizado " + fechaActual;
            }

            CrearGraficoPedidosCliente();
            CrearGraficoProductosCategoria();
        }

        /// <summary>
        /// Al cargar el dashboard, se inicia el temporizador para refrescar la información
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            ConfigurarTemporizador();
        }

        private void ConfigurarTemporizador()
        {
            dtTemporizador = new DispatcherTimer();
            dtTemporizador.Tick += timer_tick!;
            dtTemporizador.Interval = new TimeSpan(0, 0, tiempoTemporizador);

            dtTemporizador.Start();
        }


        /// <summary>
        /// Proceso a realizar tras cada intervalo de tiempo definido en el temporizador
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer_tick(object sender, EventArgs e)
        {
            ActualizarInformacion();

            //Forcing the CommandManager to raise the RequerySuggested event
            CommandManager.InvalidateRequerySuggested();
        }

        /// <summary>
        /// Actualiza el intervalo del temporizador, para el que estaba funcionando y pone en marcha con el nuevo intervalo
        /// </summary>
        /// <param name="actualizarTemporizador"></param>
        public void ActualizarIntervaloTemporizador(int tiempoTemporizador)
        {
            this.tiempoTemporizador = tiempoTemporizador;

            if (dtTemporizador != null)
                dtTemporizador.Stop();

            ConfigurarTemporizador();
        }
    }
}
