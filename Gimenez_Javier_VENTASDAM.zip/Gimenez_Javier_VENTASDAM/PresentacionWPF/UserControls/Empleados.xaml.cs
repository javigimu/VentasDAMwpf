﻿using Microsoft.Win32;
using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.DirectoryServices;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PresentacionWPF.UserControls
{
    /// <summary>
    /// Lógica de interacción para Empleados.xaml
    /// </summary>
    public partial class Empleados : UserControl
    {
        private Employee? empleado;
        private string? operacion;
        private ICollection<Employee> empleados;

        public Empleados()
        {
            InitializeComponent();
            empleado = new Employee();
            operacion = null;            
            this.DataContext = empleado;

            empleados = Gestion.ListadoEmpleados();
            empleados.Add(new Employee());
            cbSupervisor.DataContext = empleados.OrderBy(e => e.FirstName);
        }        

        /// <summary>
        /// Constructor para utilizar en la modificación de un empleado
        /// </summary>
        /// <param name="empleado"></param>
        public Empleados(Employee empleado, string operacion) : this()
        {
            this.empleado = empleado;
            this.operacion = operacion;
            MostrarTitulo(operacion);            
        }

        /// <summary>
        /// Muestra en la parte superior de la ventana, el título correspondiente según la operación, siendo la inserción el valor por defecto
        /// </summary>
        /// <param name="operacion">modificar o borrar</param>
        /// <exception cref="NotImplementedException"></exception>
        private void MostrarTitulo(string operacion)
        {
            tbTituloOperacion.Text = operacion.ToUpper() + " EMPLEADO";
            if (operacion == "eliminar")
                btnResetear.Visibility = Visibility.Hidden;
        }

        /// <summary>
        /// Permite al usuario adjuntar una foto para el empleado y la muestra en imgFoto
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AdjuntarFoto(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                byte[]? foto;
                string imagen = openFileDialog.FileName;
                tbFotoPath.DataContext = empleado;
                if (imagen != "")
                {
                    foto = File.ReadAllBytes(imagen);
                    empleado!.Photo = foto;
                    MostrarFotoSeleccionada(foto);                    
                }
                imgFoto.DataContext = empleado;
            }            
        }

        /// <summary>
        /// Muestra la foto seleccionada en imgFoto
        /// </summary>
        /// <param name="foto"></param>
        private void MostrarFotoSeleccionada(byte[] foto)
        {
            BitmapImage bi;
            using (var ms = new MemoryStream(foto))
            {
                bi = new BitmapImage();
                bi.BeginInit();
                bi.CreateOptions = BitmapCreateOptions.None;
                bi.CacheOption = BitmapCacheOption.OnLoad;
                bi.StreamSource = ms;
                bi.EndInit();
            }
            imgFoto.Source = bi;
        }

        /// <summary>
        /// Verificar que no haya ningún campo con error de validación
        /// </summary>
        /// <returns></returns>
        private bool VerificarCamposValidados()
        {
            bool validacionOk = tbNombre.Text.Length > 0 && tbApellido.Text.Length > 0;
            
            if (Validation.GetHasError(tbNombre)) validacionOk= false;
            if (Validation.GetHasError(tbApellido)) validacionOk= false;
            if (Validation.GetHasError(tbTituloCortesia)) validacionOk= false;
            if (Validation.GetHasError(tbDireccion)) validacionOk = false;
            if (Validation.GetHasError(tbCiudad)) validacionOk = false;
            if (Validation.GetHasError(tbRegion)) validacionOk = false;
            if (Validation.GetHasError(tbCodigoPostal)) validacionOk = false;
            if (Validation.GetHasError(tbPais)) validacionOk = false;
            if (Validation.GetHasError(dtFechaNacimiento)) validacionOk = false;
            if (Validation.GetHasError(tbTelefono)) validacionOk = false;
            if (Validation.GetHasError(tbExtension)) validacionOk = false;
            if (Validation.GetHasError(tbTitulo)) validacionOk = false;
            if (Validation.GetHasError(dtFechaContratacion)) validacionOk = false;
            if (Validation.GetHasError(tbFotoPath)) validacionOk = false;
            if (Validation.GetHasError(tbAnotaciones)) validacionOk = false;
            if (Validation.GetHasError(tbEmpleadoSupervisor)) validacionOk = false;

            return validacionOk;
        }

        /// <summary>
        /// Inserta, modifica o elimina el empleado con los valores del formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (VerificarCamposValidados())
            {
                textoAceptar.Foreground = System.Windows.Media.Brushes.DarkCyan;
                using (Gestion gestion = new Gestion())
                {
                    if (empleado != null)
                    {
                        if (operacion == "modificar")
                        {
                            gestion.ActualizarEmployee(empleado);
                            textoAceptar.Content = "Empleado modificado correctamente!!";
                        }
                        else if (operacion == "eliminar")
                        {
                            ConfirmacionSalida dialogoConfirmacion = new ConfirmacionSalida("Se va a eliminar el empleado, ¿Continuar?");
                            if (dialogoConfirmacion.ShowDialog() == true)
                            {
                                gestion.BorrarEmployee(empleado);
                                textoAceptar.Content = "Empleado eliminado correctamente!!";
                                btnAceptar.IsEnabled = false;
                            }
                        }
                        else
                        {
                            gestion.InsertarEmployee(empleado);
                            textoAceptar.Content = "Empleado insertado correctamente!!";
                            ResetearEmpleado();
                        }
                    }
                }
            }
            else
            {
                if (tbNombre.Text.Length == 0)
                    textoAceptar.Content = "El nombre no puede estar vacío";
                else if (tbApellido.Text.Length == 0)
                    textoAceptar.Content = "El apellido no puede estar vacío";
                else 
                    textoAceptar.Content = "Error: hay campos con error de validación!!";
                textoAceptar.Foreground = System.Windows.Media.Brushes.Red;
            }
        }

        /// <summary>
        /// Resetea el empleado y se vacían los campos
        /// </summary>
        public void ResetearEmpleado()
        {
            empleado = new Employee();
            this.DataContext = empleado;
        }

        /// <summary>
        /// Resetea todos los valores del formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnResetear_Click(object sender, RoutedEventArgs e)
        {
           ResetearEmpleado();
        }

        /// <summary>
        /// Cancela la inserción, modificación o borrado del empleado y vuelve al dashboard
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            var padre = Window.GetWindow(this) as PresentacionWPF.FormularioPrincipal; 
            if (padre != null)
            {
                padre.stackPanelPrincipal.Children.Clear();
                padre.stackPanelPrincipal.Children.Add(new DashBoard());
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {            
            if (operacion != null)
            {
                this.DataContext = empleado;                
            }               

            if (operacion == "eliminar")
                BloquearEdicionDeCampos();
        }

        /// <summary>
        /// Bloquea los campos para evitar su edición, sólo se muestran los datos y se permite al usuario eliminar el empleado o cancelar
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void BloquearEdicionDeCampos()
        {
            groupDatosPersonales.IsEnabled = false;
            groupDatosProfesionales.IsEnabled = false;
        }

        /// <summary>
        /// Al cambiar la selección de un empleado supervisor, se actualiza el campo del empleado
        /// Se permite marcar un empleado vacío, que representa el no selección de empleado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbSupervisor_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Employee eSupervisor = (Employee)cbSupervisor.SelectedItem;
            if (eSupervisor.EmployeeId != 0) 
            {
                tbEmpleadoSupervisor.Text = eSupervisor.EmployeeId.ToString();
            }            
        }
    }
}
