﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Xps.Packaging;
using System.Windows.Xps;
using PresentacionWPF.Dialogos;

namespace PresentacionWPF.UserControls
{
    /// <summary>
    /// Lógica de interacción para Informes.xaml
    /// <autor>Javier Giménez</autor>
    /// </summary>
    public partial class Informes : UserControl
    {
        private Order? pedido;
        private ICollection<OrderDetail>? detallesPedido;
        public FixedDocumentSequence? Document { get; set; }

        public Informes()
        {
            InitializeComponent();           
            tbFechaFactura.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }

        private void MostrarLineasPedido(int orderId)
        {
            this.DataContext = pedido;

            using (Gestion gestion = new Gestion())
            {
                detallesPedido = gestion.ListarOrderDetails(orderId);
                if (detallesPedido != null)
                    gestion.llenarOrderDetailConProductos(detallesPedido);

                if (detallesPedido != null)
                {
                    dgDetallesPedido.Items.Clear();
                    foreach (OrderDetail dp in detallesPedido)
                    {
                        string productName = "";
                        if (dp.Product != null)
                            productName = dp.Product.ProductName;

                        int discount = (int)(dp.Discount * 100);


                        DetallePedido detallePedido = new DetallePedido(dp.ProductId, productName, dp.UnitPrice, dp.Quantity, discount);
                        dgDetallesPedido.Items.Add(detallePedido);
                    }
                }               
            }
            CalcularTotales();
        }

        /// <summary>
        /// Actualiza los totales del pedido
        /// </summary>
        private void CalcularTotales()
        {
            lbTotalSinIva.Content = "";
            lbTotalIva.Content = "";
            lbTotalFactura.Content = "";

            Gestion.TotalSinIva = 0;

            foreach (DetallePedido orderDetail in dgDetallesPedido.Items)
            {
                decimal precio = Convert.ToDecimal(orderDetail.UnitPrice);
                short cantidad = Convert.ToInt16(orderDetail.Quantity);
                float descuento = (float)(precio * cantidad) * Convert.ToSingle(orderDetail.Discount) / 100.0f;
                decimal total = (precio * cantidad) - (decimal)descuento;
                Gestion.TotalSinIva += precio * cantidad - (decimal)descuento;
                lbTotalSinIva.Content = Gestion.TotalSinIva.ToString("N2");
                lbTotalIva.Content = (Gestion.TotalSinIva * (decimal)0.21).ToString("N2");
                lbTotalFactura.Content = Gestion.TotalPedido.ToString("N2");
            }
        }

        private void btnImprimir_Click(object sender, RoutedEventArgs e)
        {
            FlowDocumentScrollViewer visual = (FlowDocumentScrollViewer)(FindName("factura"));

            try
            {
                // write the XPS document
                using (XpsDocument doc = new XpsDocument("printPreview.xps", FileAccess.Write))
                {
                    XpsDocumentWriter writer = XpsDocument.CreateXpsDocumentWriter(doc);
                    writer.Write(visual);
                }

                // Read the XPS document into a dynamically generated
                // preview Window 
                Window preview = new ImpresionInforme();
                using (XpsDocument doc = new XpsDocument("printPreview.xps", FileAccess.Read))
                {
                    FixedDocumentSequence fds = doc.GetFixedDocumentSequence();

                    DocumentViewer dv1 = LogicalTreeHelper.FindLogicalNode(preview, "vistaPrevia") as DocumentViewer;
                    dv1.Document = fds as IDocumentPaginatorSource;

                    // Eliminamos la ventana de búsqueda
                    ContentControl cc = dv1.Template.FindName("PART_FindToolBarHost", dv1) as ContentControl;
                    cc.Visibility = Visibility.Collapsed;
                }
                preview.ShowDialog();
            }
            finally
            {
                if (File.Exists("printPreview.xps"))
                {
                    try
                    {
                        File.Delete("printPreview.xps");
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void btnSelecionPedido_Click(object sender, RoutedEventArgs e)
        {
            SeleccionPedido dialogoSeleccionPedido = new SeleccionPedido();
            dialogoSeleccionPedido.ShowDialog();
            if (dialogoSeleccionPedido.DialogResult == true)
            {
                pedido = dialogoSeleccionPedido.getPedido();
                if (pedido != null)
                    MostrarLineasPedido(pedido.OrderId);
            }
        }
    }
}
