﻿using Modelos;
using Negocio;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Drawing;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Collections.Specialized.BitVector32;

namespace PresentacionWPF.UserControls
{
    /// <summary>
    /// Lógica de interacción para Pedidos.xaml
    /// </summary>
    public partial class Pedidos : UserControl
    {
        private Employee? empleado;
        private ICollection<Customer> clientes;
        private string textoFiltrado;
        private Customer? cliente;
        private ICollection<Order>? pedidosCliente;
        private Order? pedido;

        public Pedidos()
        {
            InitializeComponent();
            clientes = Gestion.ListadoClientes();
            textoFiltrado = "";
        }

        public Pedidos(Employee empleado) : this()
        {
            this.empleado = empleado;
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (Customer cliente in clientes)
            {
                lvClientes.Items.Add(cliente);
            }
            RellenarComboBoxTipoEnvio();
        }

        /// <summary>
        /// Llena el combobox con los tipos de envío
        /// </summary>
        private void RellenarComboBoxTipoEnvio()
        {
            if (cbShipVia.Items.Count == 0)
            {
                ICollection<Shipper> shippers = Gestion.ListadoShippers();
                foreach (Shipper s in shippers)
                {
                    cbShipVia.Items.Add(s);
                }
            }
        }

        /// <summary>
        /// Filtra los clientes a mostrar 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbTextoFiltrado_KeyUp(object sender, KeyEventArgs e)
        {
            textoFiltrado = tbTextoFiltrado.Text.Trim().ToLower();
            lvClientes.Items.Clear();
            foreach (Customer cliente in clientes)
            {
                if (cliente.CustomerId.ToLower().Contains(textoFiltrado) || 
                    (cliente.ContactName != null && cliente.ContactName.ToLower().Contains(textoFiltrado)) || 
                    (cliente.CompanyName != null && cliente.CompanyName.ToLower().Contains(textoFiltrado)))
                {
                    lvClientes.Items.Add(cliente);
                }
            }
        }
        
        /// <summary>
        /// Muestra los datos del cliente seleccionado en la lista y recoge todos sus datos, incluido sus pedidos
        /// Se muestra el botón para crear un nuevo pedido y si el cliente tiene pedidos sin enviar (ShippedDate)
        /// se muestran para que se pueda seleccionar uno a modificar
        /// </summary>
        private void MostrarDatosCliente()
        {
            stackNuevoPedido.Visibility = Visibility.Visible;
            stackDatosPedido.Visibility = Visibility.Visible;

            cliente = (Customer)lvClientes.SelectedItem;
            if (cliente != null)
            {
                stackDatosCliente.Visibility = Visibility.Visible;

                tbTitle.Text = cliente.ContactTitle;
                tbPhone.Text = cliente.Phone;

                pedidosCliente = Gestion.ListarPedidosCliente(cliente.CustomerId);
                MostrarPedidosCliente();
            }
        }

        /// <summary>
        /// Muestra los datos del pedido seleccionado
        /// </summary>
        private void MostrarPedidosCliente()
        {
            ResetearTotales();
            lvPedidos.Items.Clear();
            if (pedidosCliente != null)
            {
                stackPedidosCliente.Visibility = Visibility.Visible;  
                foreach (Order pedido in pedidosCliente)
                {
                    if (pedido.ShippedDate == null)
                        lvPedidos.Items.Add(pedido);
                }
            } 
        }

        private void btnSeleccionar_Click(object sender, RoutedEventArgs e)
        {
            MostrarDatosCliente();
        }

        private void lvClientes_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MostrarDatosCliente();
        }

        /// <summary>
        /// Muestra los datos del pedido seleccionado para modificar
        /// </summary>
        private void MostrarDatosPedidoCliente()
        {           
            btnModificarPedido.Visibility = Visibility.Visible;
            pedido = (Order)lvPedidos.SelectedItem;
            stackDatosPedido.DataContext = pedido;

            if (pedido.OrderDetails != null)
            {
                ICollection<OrderDetail> detallesPedido = pedido.OrderDetails;

                if (dgPedido.Items.Count > 0)
                {
                    dgPedido.Items.Clear();
                    detallesPedido.Clear();
                }

                foreach (OrderDetail dp in detallesPedido)
                {
                    dgPedido.Items.Add(dp);
                    detallesPedido.Add(dp);
                }

                if (pedido.ShipVia != null)
                {
                    int shipVia = (int)pedido.ShipVia;
                    cbShipVia.SelectedIndex = shipVia - 1;                                     
                }

                CalcularTotales();
            }
        }

        private void btnModificarPedido_Click(object sender, RoutedEventArgs e)
        {
            MostrarDatosPedidoCliente();
        }

        private void lvPedidos_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MostrarDatosPedidoCliente();       
        }

        private void lvClientes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ResetearPedido();
        }

        /// <summary>
        /// Resetea los datos del pedido introducidos hasta el momento
        /// </summary>
        private void ResetearPedido()
        {
            pedido = null;
            if (pedidosCliente != null)
                pedidosCliente.Clear();            

            if (dgPedido != null)
                dgPedido.Items.Clear();

            dpFechaEnvio.SelectedDate = null;
            dpFechaPedido.SelectedDate = null;
            dpFechaRequerida.SelectedDate = null;
            tbNombreEnvio.Clear();
            cbShipVia.SelectedIndex = -1;
            tbPesoEnvio.Clear();
            tbPaisEnvio.Clear();
            tbCiudadEnvio.Clear();
            tbDireccionEnvio.Clear();
            tbCPEnvio.Clear();
            tbRegionEnvio.Clear();

            btnModificarPedido.Visibility = Visibility.Hidden;
        }

        /// <summary>
        /// Resetea los datos del pedido, si hubier
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNuevoPedido_Click(object sender, RoutedEventArgs e)
        {
            ResetearPedido();
        }

        /// <summary>
        /// Actualiza los totales del pedido
        /// </summary>
        private void CalcularTotales()
        {
            Gestion.TotalSinIva = 0;

            foreach (OrderDetail orderDetail in dgPedido.Items)
            {
                decimal precio = Convert.ToDecimal(orderDetail.UnitPrice);
                short cantidad = Convert.ToInt16(orderDetail.Quantity);
                float descuento = (float)(precio * cantidad) * Convert.ToSingle(orderDetail.Discount) / 100.0f;
                decimal total = (precio * cantidad) - (decimal)descuento;
                Gestion.TotalSinIva += precio * cantidad - (decimal)descuento;
                tbTotalSinIva.Content = Gestion.TotalSinIva.ToString("N2");
                tbIva.Content = (Gestion.TotalSinIva * (decimal)0.21).ToString("N2");
                tbTotalPedido.Content = Gestion.TotalPedido.ToString("N2");
            }
        }

        /// <summary>
        /// Resetea los datos de los totales del pedido
        /// </summary>
        private void ResetearTotales()
        {
            tbTotalSinIva.Content = "";
            tbIva.Content = "";
            tbTotalPedido.Content = "";
            Gestion.TotalSinIva = 0;
        }

        /// <summary>
        /// Abre un diálogo para seleccionar un producto que añadir al pedido
        /// </summary>
        private void AnyadirProducto()
        {
            SeleccionLineaPedido dialogoProducto = new SeleccionLineaPedido();
            dialogoProducto.ShowDialog();
            if (dialogoProducto.DialogResult == true)
            {           
                Product? producto = dialogoProducto.getProduct();
                short cantidad = 0;
                OrderDetail? orderDetail = null;

                if (producto != null)
                {
                    orderDetail = ObtenerCantidadProductoEnPedido(producto.ProductId);
                }

                if (orderDetail != null)
                {
                    cantidad = orderDetail.Quantity;
                }
                cantidad += dialogoProducto.getCantidad();
                int descuento = dialogoProducto.getDescuento();
                descuento = descuento > 100 ? 100 : descuento;

                if (producto != null)
                {
                    decimal precio = producto.UnitPrice == null? 1 : producto.UnitPrice.Value;
                    
                    if (orderDetail == null)
                    {
                        orderDetail = new OrderDetail(0, producto.ProductId, precio, cantidad, descuento);
                    }
                    else
                    {
                        orderDetail.Quantity = cantidad;
                    }
                    
                    orderDetail.Product = producto;
                    dgPedido.Items.Add(orderDetail);
                }

                CalcularTotales();
            }
        }

        /// <summary>
        /// Si el producto ya se encuentra en el pedido, se devuelve la cantidad sino 0
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        private OrderDetail? ObtenerCantidadProductoEnPedido(int productId)
        {
            foreach (OrderDetail orderDetail in dgPedido.Items)
            {
                if (productId == orderDetail.ProductId)
                {
                    dgPedido.Items.Remove(orderDetail);
                    return orderDetail;
                }                                
            }
            return null;
        }

        /// <summary>
        /// Eliminar un producto del pedido
        /// </summary>
        private void EliminarProducto()
        {
            dgPedido.Items.Remove(dgPedido.SelectedItem);
            CalcularTotales();
        }

        /// <summary>
        /// Añade un nuevo producto al pedido desde el botón de Añadir producto
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNuevoProducto_Click(object sender, RoutedEventArgs e)
        {
            AnyadirProducto();   
        }

        /// <summary>
        /// Añade un nuevo producto al pedido desde el menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemAnyadirProducto_Click(object sender, RoutedEventArgs e)
        {
            AnyadirProducto();
        }

        /// <summary>
        /// Elimina un producto del pedido desde el menú contextual
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItemEliminarProducto_Click(object sender, RoutedEventArgs e)
        {
            EliminarProducto();
        }

        private void btnEliminarRegistro_Click(object sender, RoutedEventArgs e)
        {
            EliminarProducto();
        }

        /// <summary>
        /// Confirma el pedido, lo guarda en la base de datos, muestra un mensaje informativo y resetea los datos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConfirmarPedido_Click(object sender, RoutedEventArgs e)
        {
            if (cliente != null)
            {
                string? customerId = cliente.CustomerId;
                int? empleadoId = empleado != null ? empleado.EmployeeId : null;
                DateTime? fechaPedido = null;
                if (dpFechaPedido.SelectedDate != null)
                    fechaPedido = dpFechaPedido.SelectedDate;
                DateTime? fechaRequerida = null;
                if (dpFechaRequerida.SelectedDate != null)
                    fechaRequerida = dpFechaRequerida.SelectedDate;
                DateTime? fechaEnvio = null;
                if (dpFechaEnvio.SelectedDate != null)
                    fechaEnvio = dpFechaEnvio.SelectedDate;

                int? shipVia = null;
                if (cbShipVia.SelectedIndex >= 0 && cbShipVia.SelectedItem != null)
                {
                    shipVia = ((Shipper)cbShipVia.SelectedItem).ShipperId;
                }

                decimal? peso = tbPesoEnvio.Text == "" ? null : Convert.ToDecimal(tbPesoEnvio.Text, new CultureInfo("en-US"));
                string? nombreEnvio = tbNombreEnvio.Text == "" ? null : tbNombreEnvio.Text;

                string? direccion = tbDireccionEnvio.Text == "" ? null : tbDireccionEnvio.Text;
                string? ciudad = tbCiudadEnvio.Text == "" ? null : tbCiudadEnvio.Text;
                string? region = tbRegionEnvio.Text == "" ? null : tbRegionEnvio.Text;
                string? codigoPostal = tbCPEnvio.Text == "" ? null : tbCPEnvio.Text;
                string? pais = tbPaisEnvio.Text == "" ? null : tbPaisEnvio.Text;

                // Inserción o actualización del pedido
                int orderId = 0;
                using (Gestion gestion = new Gestion())
                {
                    if (pedido == null) // es un pedido nuevo
                    {
                        pedido = new Order(0, customerId, empleadoId, fechaPedido, fechaRequerida,
                            fechaEnvio, shipVia, peso, nombreEnvio, direccion, ciudad, region,
                            codigoPostal, pais);

                        orderId = gestion.InsertarOrderYDevolverId(pedido); // inserción del pedido en la base de datos
                    }
                    else // se está modificando el pedido
                    {
                        pedido.CustomerId = customerId;
                        pedido.EmployeeId = empleadoId;
                        pedido.OrderDate = fechaPedido;
                        pedido.ShippedDate = fechaRequerida;
                        pedido.ShippedDate = fechaEnvio;
                        pedido.ShipVia = shipVia;
                        pedido.Freight = peso;
                        pedido.ShipName = nombreEnvio;
                        pedido.ShipAddress = direccion;
                        pedido.ShipCity = ciudad;
                        pedido.ShipRegion = region;
                        pedido.ShipPostalCode = codigoPostal;
                        pedido.ShipCountry = pais;

                        //gestion.ActualizarOrder(pedido); // actualización del pedido
                        orderId = pedido.OrderId;
                        BorrarOrderDetailPedido();
                    }

                    // Inserción de las order details del pedido
                    ICollection<OrderDetail> listaOrderDetails= new HashSet<OrderDetail>();

                    foreach (OrderDetail orderDetail in dgPedido.Items)
                    {
                        orderDetail.OrderId = orderId;
                        if (orderDetail.Discount > 10)
                            orderDetail.Discount = orderDetail.Discount / 100.0f;
                        gestion.InsertarOrderDetail(orderDetail);    
                        listaOrderDetails.Add(orderDetail);
                    }

                    pedido.OrderDetails = listaOrderDetails;
                    gestion.ActualizarOrder(pedido); // actualización del pedido
                    // Informo de la finalización correcta y reseteo los datos del pedido
                    MostrarMensajeConfirmacion();
                    ResetearPedido();
                    pedidosCliente = Gestion.ListarPedidosCliente(cliente.CustomerId);
                    MostrarPedidosCliente(); // actualizo los pedidos del cliente
                }    
            }
        }

        /// <summary>
        /// Muestra una ventana para informar de que la operación ha finalizado correctamente
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void MostrarMensajeConfirmacion()
        {
            MensajeConfirmacion dialogoMensaje = new MensajeConfirmacion();
            dialogoMensaje.ShowDialog();
        }

        /// <summary>
        /// Borra los order detail del pedido que se va a modificar para dejar únicamente los que ha dejado el usuario en la modificación
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        private void BorrarOrderDetailPedido()
        {
            using (Gestion gestion = new Gestion())
            {
                if (pedido != null)
                {
                    ICollection<OrderDetail>? listaOrderDetailsPedido = gestion.ListarOrderDetails(pedido.OrderId);
                    if (listaOrderDetailsPedido != null)
                    {
                        foreach (OrderDetail od in listaOrderDetailsPedido)
                        {
                            gestion.BorrarOrderDetail(od);
                        }
                    }                    
                }
               
            }
        }

        /// <summary>
        /// Sólo permite introducir números en un textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}

