﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PresentacionWPF
{
    /// <summary>
    /// <author>Javier Giménez Muñoz</author>
    /// </summary>
    public class Utils
    {
        /// <summary>
        /// Valida si un texto está formado sólo por números
        /// </summary>
        /// <param name="texto">text a validar</param>
        /// <returns>true si el texto está formado sólo por números</returns>
        public static bool ValidarTextoEsNumero(string texto)
        {
            Regex regex = new Regex("^[0-9]+$");
            return regex.IsMatch(texto);
        }

    }
}
