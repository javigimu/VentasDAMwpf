﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;

namespace PresentacionWPF.ValidationRules
{
    public class VRCampoGenerico: ValidationRule
    {
        public int Max { get; set; }
        public int Min { get; set; }
        public bool IsPhotoPath { get; set; }
        public bool IsBirthDate { get; set; }
        public bool IsPhone { get; set; }
        public bool IsSupervisor { get; set; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (IsBirthDate)
            {
                if ((DateTime)value >= DateTime.Now)
                {
                    return new ValidationResult(false,
                        "La fecha de nacimiento debe ser inferior a la fecha actual");
                }
            }
            else
            {
                if (((string)value).Length > Max)
                {
                    return new ValidationResult(false,
                        "La longitud debe de ser inferior a : " + Max + ".");
                }

                if (IsPhotoPath)
                {
                    string patronHttp = "^http://(www.)?([a-z0-9](-?/?[a-z0-9])*.[a-z]{2,3})+$";
                    string patronHttps = "^https://(www.)?(([a-z0-9]+.){2,}.[a-z]{2,3}.[a-z]{2,3})(/([a-z0-9-]+/?))*$";

                    if (((string)value).Length > 0)
                    {
                        if (((string)value).Length > Max)
                        {
                            return new ValidationResult(false,
                                "La longitud debe de ser inferior a : " + Max + ".");
                        }
                        else if (!Regex.IsMatch((string)value, patronHttp) && !Regex.IsMatch((string)value, patronHttps))
                        {
                            return new ValidationResult(false,
                                "No es una dirección bien formada");
                        }
                    }                    
                }

                if (IsPhone)
                {
                    string patronPhone = "^[0-9]{9,12}$";

                    if (((string)value).Length > 0 && 
                        (!Regex.IsMatch((string)value, patronPhone) || ((string)value).Length < Min || ((string)value).Length > Max))
                    {
                        return new ValidationResult(false,
                            "El teléfono debe contener entre 9 y 12 dígitos");
                    }
                }

                if (IsSupervisor)
                {
                    string patronEmpleado = "^[0-9]+$";
                    if (Regex.IsMatch((string)value, patronEmpleado))
                    {
                        int empleadoid = Convert.ToInt32((string)value);
                        using (Gestion gestion = new Gestion())
                        {

                            if (gestion.ObtenerEmpleado(empleadoid) == null)
                            {
                                return new ValidationResult(false,
                                    "El empleado supervisor no existe");
                            }
                        }
                    }
                    else
                    {
                        return new ValidationResult(false,
                            "El empleado supervisor debe estar compuesto por dígitos");
                    }
                }
            }

            return ValidationResult.ValidResult;        
        }
    }
}
